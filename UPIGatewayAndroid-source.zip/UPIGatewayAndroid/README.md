# UPI Gateway Android app — starter demo

This is the first Android app shell, designed to be developed before the website/backend. It currently runs a local offline UI inside Android WebView.

## Current screens
- Merchant overview dashboard
- Sample transactions
- Demo payment amount/QR preview (does NOT generate a payable QR)
- Profile/settings placeholder

## Important
- All displayed transaction amounts and statuses are sample data.
- No real payment is accepted, initiated, or verified in this build.
- Do not put UPI/provider/API secret credentials in the APK.
- Live UPI payments require a deployed HTTPS backend and a verified payment provider or supported merchant integration. The app can be connected to that backend later without rebuilding the UI from scratch.

## Build
1. Open this folder in Android Studio (Hedgehog or newer).
2. Let Gradle sync; install Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK on an Android device.

Application ID: `com.example.upigateway`
Min Android: 6.0 (API 23)
